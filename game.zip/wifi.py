import os
import base64

def assemble_game_module(folder_name="system", num_parts=50, prefix="part_", suffix=".dll"):
    """
    Последовательно собирает данные из фрагментов, декодируя их из Base64 и Hex.
    Возвращает полный массив байтов исходного модуля/файла.
    """
    assembled_bytes = bytearray()
    
    for part_num in range(1, num_parts + 1):
        # Формируем имя файла, например: system/part_1.dll
        filename = f"{prefix}{part_num}{suffix}"
        file_path = os.path.join(folder_name, filename)
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Критическая ошибка: отсутствует компонент игры {filename}")
            
        with open(file_path, "rb") as file:
            # 1. Читаем закодированный фрагмент
            encoded_base64 = file.read()
            
            # 2. Декодируем из Base64 обратно в Hex-строку (байты ASCII)
            hex_bytes = base64.b64decode(encoded_base64)
            
            # 3. Преобразуем Hex-байты в исходные бинарные данные
            # Метод bytes.fromhex принимает строку или байты, содержащие шестнадцатеричные символы
            raw_chunk = bytes.fromhex(hex_bytes.decode("ascii"))
            
            # Добавляем полученный фрагмент в общий массив
            assembled_bytes.extend(raw_chunk)
            
    return bytes(assembled_bytes)

# Пример использования в коде игры:
try:
    game_code_bytes = assemble_game_module()
    print(f"Модуль успешно собран. Размер: {len(game_code_bytes)} байт.")
    print("Запуск")
    exec(game_code_bytes) 
except Exception as e:
    print(f"Не удалось запустить игру: {e}")

