import sys
import uuid
import os
import time
import threading
import socket
import json
import zipfile
try:
    import requests
except:
    os.system("pip install requests")


def get_version():
    with open("/sdcard/gametest/files/version") as f:
        return f.read()

def unzip(file_path):
    with zipfile.ZipFile(file_path, 'r') as zip_ref:
        zip_ref.extractall()


def check_update():
    response = requests.get("https://tornado-2024.github.io/Miniinline/version")
    if response.text.strip() != get_version().strip():
        print(f"Подождите Выполняется Обновление С {get_version()} На {response.text}")
        zip_response = requests.get("https://tornado-2024.github.io/Miniinline/game.zip")
        with open("/sdcard/gametest/files/game.zip", 'wb') as f:
            f.write(zip_response.content)
        unzip("/sdcard/gametest/files/game.zip")
        print("Обновление Выполнено Перезайдите Чтобы Начать Играть")
        time.sleep(3)
        sys.exit(0)




def check_files(file_list):
    result = {}
    current_dir = os.getcwd()
    for filename in file_list:
        result[filename] = os.path.isfile(os.path.join(current_dir, filename))
    return result

def get_inventory(id):
    file_path = "/sdcard/gametest/files/inventory.json"
    if os.path.exists(file_path):
        try:
            with open(file_path, "r") as file:
                text = file.read().strip()
                if text:
                    return text
        except:
            pass
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    try:
        with open(file_path, "w") as file:
            file.write("{}")
    except:
        pass
    return "{}"

def clear():
    os.system("clear")

def get_id():
    file_path = "/sdcard/gametest/files/id.txt"
    if os.path.exists(file_path):
        try:
            with open(file_path, "r") as file:
                text = file.read().strip()
                if text:
                    return text
        except:
            pass
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    new_id = str(uuid.uuid4())
    try:
        with open(file_path, "w") as file:
            file.write(new_id)
    except:
        pass
    return new_id

def prompt_password():
    return True

def license_check():
    pass

def load_config():
    path = "/sdcard/gametest/config.json"
    if not os.path.exists(path):
        return {"name": "Игрок"}
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except Exception as e:
        print("Ошибка загрузки конфигурации:", e)
        return {"name": "Игрок", "server_name": "server"}

def update_config(config):
    path = "/sdcard/gametest/config.json"
    try:
        with open(path, 'w') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print("Ошибка сохранения конфигурации:", e)

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "0.0.0.0"
    finally:
        s.close()
    return ip

def recv_json(sock):
    buffer = ""
    while True:
        try:
            data = sock.recv(1024).decode('utf-8')
            if not data:
                return None
            buffer += data
            if '\n' in buffer:
                line, buffer = buffer.split('\n', 1)
                return json.loads(line)
        except json.JSONDecodeError:
            continue
        except Exception:
            return None

def send_json(sock, obj):
    try:
        msg = json.dumps(obj) + '\n'
        sock.sendall(msg.encode('utf-8'))
    except Exception:
        pass

def progress_bar(current, total, length=20):
    if total == 0:
        percent = 0
    else:
        percent = current / total
    filled = int(length * percent)
    bar = '#' * filled + ' ' * (length - filled)
    pct_text = f"{percent * 100:5.1f}%"
    sys.stdout.write(f"\rЗагрузка: [{bar}] {pct_text}")
    sys.stdout.flush()

def loading():
    clear()
    print(f"Ваш ID: {get_id()}\n")
    total = 100
    for i in range(total + 1):
        progress_bar(i, total, length=20)
        time.sleep(0.1)
    print("\nГотово")

clients = []
messages = []


def handle_client(conn, addr, lock):
    player_name = "Игрок"
    players = {}
    config = load_config()
    with conn:
        with lock:
            clients.append({'conn': conn, 'name': player_name})
        buffer = ""
        while True:
            try:
                data_bytes = conn.recv(1024)
                if not data_bytes:
                    break
                buffer += data_bytes.decode('utf-8')
                while '\n' in buffer:
                    line, buffer = buffer.split('\n', 1)
                    if not line.strip():
                        continue
                    data = json.loads(line)
                    if data.get("packet_type") == "connect":
                        player_name = data['data']['name']
                        player_id = data["data"]["id"]
                        player_ip = addr[0]
                        version = data["data"]["version"]
                        print(f"[SERVER] [INFO] Подключен Игрок: \n{player_name}\nip: {player_ip}\nверсия: {version}")
                        with lock:
                            for cl in clients:
                                if cl['conn'] == conn:
                                    cl['name'] = player_name
                        # Отправляем историю чата новому игроку
                        for msg in messages:
                            send_json(conn, {"status": "ok", "message": msg})
                        send_json(
                            conn, {
                                "status": "ok", "message": "Добро пожаловать", "server_name": config.get('server_name',''),"players": players})
                        players[player_id] = True
                    elif data.get("packet_type") == "chat":
                        with lock:
                            for cl in clients:
                                if cl['conn'] == conn:
                                    player_name = cl['name']
                        text = data["data"]["message"]
                        msg = f"{player_name}: {text}"
                        with lock:
                            messages.append(msg)
                            print(msg)  # Выводим сообщение в консоль сервера
                            for cl in clients[:]:  # Отправляем всем игрокам
                                try:
                                    send_json(cl['conn'], {"status": "ok", "message": msg})
                                except Exception:
                                    clients.remove(cl)
                    elif data.get("packet_type") == "inventory":
                        with lock:
                            for cl in clients:
                                if cl['conn'] == conn:
                                    player_name = cl['name']
                                    player_id = data.get("data")['id']
                        with lock:
                            for cl in clients[:]:
                                try:
                                    send_json(cl['conn'], {"status": "ok", "data": get_inventory(player_id)})
                                except Exception as e:
                                    print(e)
            except BaseException:
                break

def run_server(messages, lock):
    HOST = get_local_ip()
    PORT = 6542
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((HOST, PORT))
    s.listen()
    with lock:
        messages.append(f"[SERVER] [INFO] Сервер запущен по адресу: {HOST}")
        print(f"[SERVER] [INFO] Сервер запущен по адресу: {HOST}")
    while True:
        try:
            conn, addr = s.accept()
            threading.Thread(target=handle_client, args=(conn, addr, lock), daemon=True).start()
        except Exception as e:
            with lock:
                messages.append(f"Ошибка при принятии соединения: {e}")
                print(f"Ошибка при принятии соединения: {e}")

def create_room(messages, lock):
    ip = get_local_ip()
    with lock:
        messages.clear()
    input("Нажмите Enter для запуска сервера")
    threading.Thread(target=run_server, args=(messages, lock), daemon=True).start()
    while True:
        command = input(">")
        if command == "stop":
            sys.exit()

def chat_mode(s, messages, lock):
    # Поток для прослушивания входящих сообщений
    def listen():
        while True:
            response = recv_json(s)
            if response and "message" in response:
                with lock:
                    messages.append(response["message"])
                    print("\n" + response["message"])
            else:
                break

    # Запускаем прослушивание в отдельном потоке
    listen_thread = threading.Thread(target=listen, daemon=True)
    listen_thread.start()

    # Основной цикл — отправка сообщений
    while True:
        text = input("Введите сообщение (пусто для выхода): ").strip()
        if not text:
            break
        name = load_config().get("name", "Игрок")
        send_json(s, {"packet_type": "chat", "data": {"message": text, "name": name}})
        with lock:
#            messages.append(f"Вы: {text}")
 #           print(f"Вы: {text}")
             pass

def inventory_mode(s, messages, lock):
    send_json(s, {"packet_type": "inventory", "data": {"id": get_id()}})
    response = recv_json(s)
    with lock:
        messages.append("Ваш инвентарь: \n")
        print("Ваш инвентарь:\n")
    input("Нажмите Enter чтобы вернуться")

def enter_room(messages, lock):
    code = input("Введите адрес комнаты: ").strip()
    HOST = f"{code}"
    PORT = 6542
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((HOST, PORT))
        name = load_config().get("name", "Игрок")
        player_id = get_id()
        send_json(s, {"packet_type": "connect", "data": {"name": name, "id": player_id, "version": get_version()}})
        data = recv_json(s)
        server_name = data.get("server_name", "null")
        if server_name == "null" and data.get("message","sjdjjd").startswith("player:"):
            print("Внимание: Возможно сервер фальшивый либо вы уже играете на этом сервере")
        with lock:
            messages.append(f"Ответ сервера: {data}")
            print(f"Ответ сервера: {json.dumps(data)}")
            time.sleep(1)
        while True:
            print(f"\nМеню сервера [{server_name}]:\n1 Инвентарь\n2 Чат\n3 Выйти")
            choice = input("Выбор: ").strip()
            if choice == "1":
                if data.get("players", {}).get(player_id, False):
                    print("Этот игрок уже на сервере. Нажмите 3, чтобы выйти.")
                else:
                    inventory_mode(s, messages, lock)
            elif choice == "2":
                if data.get("players", {}).get(player_id, False):
                    print("Этот игрок уже на сервере. Нажмите 3, чтобы выйти.")
                else:
                    chat_mode(s, messages, lock)
            elif choice == "3":
                break
        s.close()
    except Exception as e:
        with lock:
            messages.append(f"Ошибка подключения: {str(e)}")
            print(f"Ошибка подключения: {str(e)}")
        time.sleep(3)

def config_mode(messages, lock):
    config = load_config()
    choice = input(f"1 Изменить имя сервера [{config.get('server_name','')}]\n2 Изменить имя игрока [{config.get('name','')}]\n3 Выйти\nВыбор: ").strip()
    if choice == "1":
        name = input("Введите новое имя: ").strip()
        config["server_name"] = name
        update_config(config)
        with lock:
            messages.append(f"Имя успешно изменено на {name}")
            print(f"Имя успешно изменено на {name}")
    elif choice == "2":
        name = input("Введите новое имя: ").strip()
        config["name"] = name
        update_config(config)
        with lock:
            messages.append(f"Имя успешно изменено на {name}")
            print(f"Имя успешно изменено на {name}")

def main_menu():
    lock = threading.Lock()
    messages = []
    menu = ["Создать Комнату", "Войти в Комнату", "Настройки", "Выйти"]
    loading()
    check_update()

    while True:
        clear()
        print("\nГлавное меню:")
        for i, item in enumerate(menu, 1):
            print(f"{i}. {item}")
        choice = input("Выберите пункт меню: ").strip()
        if choice == "1":
            clear()
            create_room(messages, lock)
        elif choice == "2":
            clear()
            enter_room(messages, lock)
        elif choice == "3":
            clear()
            config_mode(messages, lock)
        elif choice == "4":
            clear()
            print("Выход из программы.")
            break

if __name__ == "__main__":
    try:
        import flask
        from flask import send_file
    except:
        os.system("pip install flask")


    app = flask.Flask(__name__)

    @app.route("/intro")
    def intro():
        return send_file("/sdcard/gametest/files/video.mp4")

    def run_flask():
        app.run(port=5001, host="0.0.0.0")

    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()
    clear()
    time.sleep(0.10)
    clear()
    main_menu()

